package com.discode.authcatation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthcatationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthcatationApplication.class, args);
	}

}
