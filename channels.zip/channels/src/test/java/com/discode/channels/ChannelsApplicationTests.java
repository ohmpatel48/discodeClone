package com.discode.channels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChannelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
