package com.discode.channels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChannelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChannelsApplication.class, args);
	}

}
