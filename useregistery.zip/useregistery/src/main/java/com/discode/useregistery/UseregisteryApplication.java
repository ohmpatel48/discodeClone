package com.discode.useregistery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UseregisteryApplication {

	public static void main(String[] args) {
		SpringApplication.run(UseregisteryApplication.class, args);
	}

}
