package com.discode.categories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
