package com.discode.serverservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerserviceApplication.class, args);
	}

}
