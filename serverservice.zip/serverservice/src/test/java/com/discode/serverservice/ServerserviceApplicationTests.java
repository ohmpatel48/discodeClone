package com.discode.serverservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
