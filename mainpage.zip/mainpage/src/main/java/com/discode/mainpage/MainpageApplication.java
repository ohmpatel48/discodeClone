package com.discode.mainpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MainpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainpageApplication.class, args);
	}

}
