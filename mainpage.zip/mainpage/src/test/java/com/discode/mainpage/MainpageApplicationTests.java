package com.discode.mainpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainpageApplicationTests {

	@Test
	void contextLoads() {
	}

}
